
public class Main {

	public static void main(String[] args) {
		/**
		Categoria a = Categoria.TIENDAS;
		Categoria b = Categoria.ESCUELA;
		Categoria c = Categoria.CINES;
		Categoria d = Categoria.HOSPITAL;
		PuntoDeInteres p = new PuntoDeInteres({a,b});
		PuntoDeInteres q = new PuntoDeInteres({c,d});
		Localidad uno = new Localidad("Mazatlan", true, p);
		Localidad dos = new Localidad("Ciudad de Mexico", false);
		Localidad tres = new Localidad("Ecatepec", true, q);
		Mapa mapa = new Mapa({uno, dos, tres});
		SistemaNavegacion sistema = new SistemaNavegacion(mapa);
		Ruta ruta = new Ruta({"Mazatlan", "Ciudad de Mexico"}, {mapa.distancia(buscaLocalidad(uno)), mapa.distancia(buscaLocalidad(dos))});
		
		System.out.println(dos.getEsInteres());
		sistema.altaLocalidad("Ciudad de Mexico");
		System.out.println(dos.getEsInteres());
		sistema.bajaLocalidad("Ecatepec");
		System.out.println(tres.getEsInteres());
		sistema.agregaRuta({ruta});
		*/	
		
	}
	
}
