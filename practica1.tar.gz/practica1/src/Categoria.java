/**
 * Enumeracion para las categorias de los puntos de interes.
 */
public enum Categoria {

	NINGUNA,

	CENTROS_COMERCIALES,

	TIENDAS,

	HOSPITAL,

	ESCUELA,

	CINES
}
